package vn.edu.usth.testview.homepage;

import android.graphics.Bitmap;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;

import org.jetbrains.annotations.NotNull;

public class AnimationUtilBest {
    private static final int ANIMATION_DURUTION = 1000;
    private static boolean isAnimationStart;

    public static void translateAnimationBest(final ImageView viewAnimationBest, @NotNull final View startViewBest, View endViewBest,
                                              final Animation.AnimationListener animationListener){
        startViewBest.setDrawingCacheEnabled(true);
        Bitmap cacheBest = startViewBest.getDrawingCache();
        if (cacheBest == null){
            return;
        }
        Bitmap bitmapBest = Bitmap.createBitmap(cacheBest);
        startViewBest.setDrawingCacheEnabled(false);
        viewAnimationBest.setImageBitmap(bitmapBest);
        float startViewWidthCenterBest = startViewBest.getWidth()/2;
        float startViewHeightCenterBest = startViewBest.getHeight()/2;

        float endViewWidthCenterBest = endViewBest.getWidth()*0.75f;
        float endViewHeightCenterBest = endViewBest.getHeight() /2f;

        final int[] startPosBest = new int[2];
        startViewBest.getLocationOnScreen(startPosBest);

        final int[] endPosBest = new int[2];
        endViewBest.getLocationOnScreen(endPosBest);

        float fromX =startPosBest[0];
        float toX = endPosBest[0] +endViewWidthCenterBest - startViewWidthCenterBest;
        float fromY = startPosBest[1] - startViewHeightCenterBest;
        float toY = endPosBest[1]-endViewHeightCenterBest+startViewHeightCenterBest;

        AnimationSet animationSetBest = new AnimationSet(true);
        animationSetBest.setInterpolator(new AccelerateInterpolator());

        int animationDuration = 200;
        ScaleAnimation startScaleAnimationBest = new ScaleAnimation(1.0f,1.5f,1.0f,
                1.5f,startViewWidthCenterBest,startViewHeightCenterBest);
        startScaleAnimationBest.setDuration(animationDuration);

        TranslateAnimation translateAnimationBest = new TranslateAnimation(fromX,toX,fromY,toY);
        translateAnimationBest.setStartOffset(animationDuration);
        translateAnimationBest.setDuration(ANIMATION_DURUTION);

        ScaleAnimation translateScaleAnimationBest = new ScaleAnimation(1.0f,0.0f,1.0f,0.0f,toX,toY);
        translateScaleAnimationBest.setStartOffset(animationDuration);
        translateScaleAnimationBest.setDuration(ANIMATION_DURUTION);

        animationSetBest.addAnimation(startScaleAnimationBest);
        animationSetBest.addAnimation(translateAnimationBest);
        animationSetBest.addAnimation(translateScaleAnimationBest);
        if (isAnimationStart) {
            viewAnimationBest.clearAnimation();
            if (animationListener != null){
                animationListener.onAnimationEnd(null);
            }
        }
        viewAnimationBest.startAnimation(animationSetBest);
        animationSetBest.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animationBest) {
                isAnimationStart = true;
                viewAnimationBest.setVisibility(View.VISIBLE);
                startViewBest.setVisibility(View.INVISIBLE);
                if (animationListener !=null){
                    animationListener.onAnimationStart(animationBest);
                }
            }

            @Override
            public void onAnimationEnd(Animation animationBest) {
                viewAnimationBest.setVisibility(View.GONE);
                startViewBest.setVisibility(View.VISIBLE);
                if (animationListener !=null){
                    animationListener.onAnimationEnd(animationBest);
                }
                isAnimationStart = false;
            }

            @Override
            public void onAnimationRepeat(Animation animationBest) {
                if (animationListener !=null){
                    animationListener.onAnimationRepeat(animationBest);
                }

            }
        });
    }
}
